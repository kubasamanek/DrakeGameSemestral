package thedrake;

public enum PlayingSide {
    ORANGE, BLUE
}
